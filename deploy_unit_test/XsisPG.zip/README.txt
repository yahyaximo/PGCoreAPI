Hi, Team
1.Extract XsisPG.zip file
2.This is deployment file, please deploy this folder into your IIS,
3.This Project using .NET Core 6, please install dependencies eg .net core 6 or higher
4.after you are deploy the application, please restore the database using backup file PG.DB.sql on root folder/same folder with this file
5.Edit connection string file on "appsetting.json",like user, password, Postgresql Server name, following your machine environment setting


yahyarozi@gmail.com